تسنيم - نسخة Build
الملف الرئيسي: index.html
واجهة Capacitor: www/index.html
تم تجهيز package.json و capacitor.config.json حتى يستطيع الـBuild تثبيت الحزم وإضافة Android.
